Detailed documentation per model

- [Regressor model for predicting risky commits](models/regressor.md)
