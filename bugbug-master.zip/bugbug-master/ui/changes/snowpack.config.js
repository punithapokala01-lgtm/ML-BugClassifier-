module.exports = {
  plugins: [
    /* ... */
  ],
  packageOptions: {
    /* ... */
  },
  devOptions: {
    /* ... */
  },
  buildOptions: {
    out: "dist",
    /* ... */
  },
  mount: {
    src: "/",
    /* ... */
  },
  alias: {
    /* ... */
  },
};
